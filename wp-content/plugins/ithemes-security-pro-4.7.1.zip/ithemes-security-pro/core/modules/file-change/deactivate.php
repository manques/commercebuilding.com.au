<?php
ITSEC_Core::get_scheduler()->unschedule( 'file-change' );