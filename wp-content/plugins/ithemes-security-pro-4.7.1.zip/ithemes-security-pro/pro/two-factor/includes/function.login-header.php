<?php

_deprecated_file( __FILE__, '3.9.0' );

require_once( ITSEC_Core::get_core_dir() . '/lib/includes/function.login-header.php' );